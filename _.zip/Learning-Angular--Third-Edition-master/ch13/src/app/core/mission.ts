export interface Mission {
  title: string;
  priority: 'low' | 'medium' | 'high';
}
