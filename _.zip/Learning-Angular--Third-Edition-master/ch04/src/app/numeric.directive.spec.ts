import { NumericDirective } from './numeric.directive';

describe('NumericDirective', () => {
  it('should create an instance', () => {
    const directive = new NumericDirective();
    expect(directive).toBeTruthy();
  });
});
