import { Component } from '@angular/core';

@Component({
  selector: 'router-outlet',
  template: ''
})
export class RouterOutletComponentStub { }
